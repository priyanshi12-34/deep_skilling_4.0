
public class FinancialForecast {

    // Recursive method to calculate future value
    public static double calculateFutureValue(double initialAmount, double growthRate, int years) {
        if (years == 0) {
            return initialAmount; // base case
        }
        return calculateFutureValue(initialAmount, growthRate, years - 1) * (1 + growthRate);
    }

    // Optimized iterative method to calculate future value
    public static double calculateFutureValueIterative(double initialAmount, double growthRate, int years) {
        double futureValue = initialAmount;
        for (int i = 1; i <= years; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }

    public static void main(String[] args) {
        double initialAmount = 10000; // ₹10,000
        double growthRate = 0.08;     // 8% annual growth
        int years = 5;

        double recursiveValue = calculateFutureValue(initialAmount, growthRate, years);
        System.out.printf("Future value after %d years (recursive): ₹%.2f%n", years, recursiveValue);

        double iterativeValue = calculateFutureValueIterative(initialAmount, growthRate, years);
        System.out.printf("Future value after %d years (iterative): ₹%.2f%n", years, iterativeValue);
    }
}
