# Exercise 2 – Implementing Dependency Injection

This mini‑project demonstrates how to wire **BookService** and **BookRepository** with Spring’s IoC container using **setter injection** configured in **`applicationContext.xml`**.

## Structure

```
library-di-exercise/
└── src
    ├── main
    │   ├── java
    │   │   └── com/example/library
    │   │       ├── BookRepository.java
    │   │       ├── BookService.java
    │   │       └── LibraryManagementApplication.java
    │   └── resources
    │       └── applicationContext.xml
```

## Build & Run

1. Add Spring Core to your classpath (e.g. with Maven):

```xml
<!-- pom.xml -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-context</artifactId>
    <version>6.1.6</version>
</dependency>
```

2. Compile:

```bash
mvn clean package
```

3. Run:

```bash
java -cp target/classes:$(mvn -q   -Dexec.executable=echo   -Dexec.args="%classpath"   --non-recursive   org.codehaus.mojo:exec-maven-plugin:1.6.0:exec)   com.example.library.LibraryManagementApplication
```

> You should see  
> `Book Title: Dummy Book Title 1`
