package com.example.library;

/**
 * Service layer that depends on BookRepository.
 * Dependency is injected via the setter method defined below.
 */
public class BookService {

    private BookRepository bookRepository;

    // Setter for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void displayBookTitle(int id) {
        String title = bookRepository.findBookTitleById(id);
        System.out.println("Book Title: " + title);
    }
}
