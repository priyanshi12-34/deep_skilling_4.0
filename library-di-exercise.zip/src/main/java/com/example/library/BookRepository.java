package com.example.library;

/**
 * Simple repository class. In real application this might connect to database.
 */
public class BookRepository {

    public String findBookTitleById(int id) {
        // Dummy in‑memory lookup
        return "Dummy Book Title " + id;
    }
}
