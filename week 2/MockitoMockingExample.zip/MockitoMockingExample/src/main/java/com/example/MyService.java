package com.example;

/** Business service that depends on ExternalApi */
public class MyService {
    private final ExternalApi externalApi;

    public MyService(ExternalApi externalApi) {
        this.externalApi = externalApi;
    }

    public String fetchData() {
        // In real scenario this might do extra processing
        return externalApi.getData();
    }
}
