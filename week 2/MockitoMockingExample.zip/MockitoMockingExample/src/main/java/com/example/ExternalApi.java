package com.example;

/** Simulated external API interface */
public interface ExternalApi {
    String getData();
}
