# Mockito Mocking Example

This project demonstrates **Exercise 1: Mocking and Stubbing** using Mockito and JUnit 5.

## Scenario
We want to test `MyService`, which depends on an external REST client `ExternalApi`.
Instead of hitting the real API, we **mock** it and **stub** its `getData()` method.

## Project Structure
```
MockitoMockingExample
 ├── pom.xml
 └── src
     ├── main/java/com/example
     │   ├── ExternalApi.java
     │   └── MyService.java
     └── test/java/com/example
         └── MyServiceTest.java
```

## Running tests
```bash
mvn test
```
The test will pass if the service correctly returns the stubbed `"Mock Data"` string and the mock interaction is verified.
