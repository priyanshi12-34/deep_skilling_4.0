# JUnit Assertions Example

This project demonstrates the use of various assertions in JUnit.

## How to Run

1. Make sure JUnit is configured in your project.
2. Run `AssertionsTest.java` as a JUnit test to validate all assertions.

## Assertions Used

- assertEquals
- assertTrue
- assertFalse
- assertNull
- assertNotNull
