/* Scenario 2: Promote customers with Balance > $10 000 to VIP */

    BEGIN
        UPDATE Customers
        SET    IsVIP = 'TRUE'
        WHERE  Balance > 10000
        AND    NVL(IsVIP, 'FALSE') = 'FALSE';

        COMMIT;
    END;
/
