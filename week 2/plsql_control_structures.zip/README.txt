PL/SQL Control‑Structure Exercises
==================================

• scenario1.sql — Apply 1 % discount to loan interest rates for customers aged > 60.
• scenario2.sql — Promote customers with balance > $10 000 to VIP.
• scenario3.sql — Print reminders for loans due in next 30 days.

Run each script in SQL*Plus or any Oracle client with:
    SQL> @scenario1.sql
