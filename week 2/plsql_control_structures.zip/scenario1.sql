/* Scenario 1: Apply 1% interest‑rate discount to customers older than 60 */

    DECLARE
        CURSOR c_customers IS
            SELECT CustomerID, InterestRate
            FROM   Loans
            WHERE  CustomerID IN (SELECT CustomerID
                                  FROM   Customers
                                  WHERE  Age > 60);

    BEGIN
        FOR rec IN c_customers LOOP
            UPDATE Loans
            SET    InterestRate = InterestRate * 0.99   -- 1 % discount
            WHERE  CustomerID   = rec.CustomerID;

        END LOOP;

        COMMIT;
    END;
/
