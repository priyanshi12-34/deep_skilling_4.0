/* Scenario 3: Reminders for loans due within the next 30 days */

    DECLARE
        v_today DATE := TRUNC(SYSDATE);
        v_due   DATE;
    BEGIN
        FOR rec IN ( SELECT l.LoanID,
                            l.CustomerID,
                            l.DueDate,
                            c.FullName
                     FROM   Loans l
                     JOIN   Customers c USING (CustomerID)
                     WHERE  l.DueDate BETWEEN v_today AND v_today + 30 )
        LOOP
            DBMS_OUTPUT.PUT_LINE('Reminder: Loan '||rec.LoanID||
                                 ' for customer '||rec.FullName||
                                 ' is due on '||TO_CHAR(rec.DueDate,'DD‑Mon‑YYYY'));
        END LOOP;
    END;
/
