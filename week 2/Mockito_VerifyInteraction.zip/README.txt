Exercise 2: Verifying Interactions

Scenario:
You need to ensure that a method is called with specific arguments.

Steps:
1. Create a mock object using Mockito.
2. Call the method under test that depends on the mock.
3. Use verify(mock).method() to confirm the method was invoked with the correct arguments.

This example verifies that 'getData()' was called on the mocked 'ExternalApi' instance.