import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CalculatorTest {

    private Calculator calculator;

    @Before
    public void setUp() {
        // Arrange: Initialize resources before each test
        calculator = new Calculator();
        System.out.println("Setup complete");
    }

    @After
    public void tearDown() {
        // Cleanup resources after each test
        calculator = null;
        System.out.println("Teardown complete");
    }

    @Test
    public void testAddition() {
        // Act: Perform the operation
        int result = calculator.add(2, 3);

        // Assert: Verify the result
        assertEquals(5, result);
    }

    @Test
    public void testAdditionWithNegative() {
        // Act
        int result = calculator.add(-1, 4);

        // Assert
        assertEquals(3, result);
    }
}
