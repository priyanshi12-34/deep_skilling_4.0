
public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Shoes", "Fashion"),
            new Product(103, "Watch", "Accessories"),
            new Product(104, "Phone", "Electronics")
        };

        Product foundLinear = SearchFunction.linearSearch(products, "Shoes");
        System.out.println("Linear Search Result: " + (foundLinear != null ? foundLinear : "Not Found"));

        Product foundBinary = SearchFunction.binarySearch(products, "Phone");
        System.out.println("Binary Search Result: " + (foundBinary != null ? foundBinary : "Not Found"));
    }
}
