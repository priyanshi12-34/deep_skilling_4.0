import React from 'react';

function App() {
  const officeList = [
    { name: 'Alpha Space', rent: 55000, address: 'MG Road, Bengaluru', image: 'https://via.placeholder.com/150' },
    { name: 'Beta Hub', rent: 62000, address: 'Powai, Mumbai', image: 'https://via.placeholder.com/150' },
    { name: 'Gamma Towers', rent: 58000, address: 'Hitech City, Hyderabad', image: 'https://via.placeholder.com/150' }
  ];

  return (
    <div>
      <h1 style={{ textAlign: 'center' }}>Office Space Rental</h1>

      {officeList.map((office, index) => (
        <div key={index} style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
          <img src={office.image} alt="office" />
          <h2>{office.name}</h2>
          <p style={{ color: office.rent < 60000 ? 'red' : 'green' }}>
            Rent: ₹{office.rent}
          </p>
          <p>Address: {office.address}</p>
        </div>
      ))}
    </div>
  );
}

export default App;
