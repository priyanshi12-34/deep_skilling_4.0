import React from 'react';

export default function UserPage() {
  return (
    <div>
      <h2>Welcome User</h2>
      <p>You can now book your tickets:</p>
      <button>Book Flight A</button>
      <button>Book Flight B</button>
      <button>Book Flight C</button>
    </div>
  );
}
