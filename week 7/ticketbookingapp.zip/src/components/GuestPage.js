import React from 'react';

export default function GuestPage() {
  return (
    <div>
      <h2>Welcome Guest</h2>
      <p>Browse flight details below (Login to book tickets):</p>
      <ul>
        <li>Flight A - 10:00 AM</li>
        <li>Flight B - 02:00 PM</li>
        <li>Flight C - 07:00 PM</li>
      </ul>
    </div>
  );
}
