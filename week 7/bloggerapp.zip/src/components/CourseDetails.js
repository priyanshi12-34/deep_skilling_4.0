import React from 'react';

export default function CourseDetails() {
  return (
    <div>
      <h2>Course Details</h2>
      <ul>
        <li>Course: Advanced React</li>
        <li>Instructor: Priyanshi</li>
      </ul>
    </div>
  );
}
