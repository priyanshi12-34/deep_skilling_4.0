import React from 'react';

export default function BlogDetails() {
  return (
    <div>
      <h2>Blog Details</h2>
      <ul>
        <li>Title: React Best Practices</li>
        <li>Author: Priyanshi</li>
      </ul>
    </div>
  );
}
