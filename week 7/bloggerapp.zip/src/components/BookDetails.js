import React from 'react';

export default function BookDetails() {
  return (
    <div>
      <h2>Book Details</h2>
      <ul>
        <li>Title: Learn React</li>
        <li>Author: Priyanshi</li>
      </ul>
    </div>
  );
}
