import React, { useState } from 'react';
import BookDetails from './components/BookDetails';
import BlogDetails from './components/BlogDetails';
import CourseDetails from './components/CourseDetails';

function App() {
  const [view, setView] = useState('book');

  const elementVariable = view === 'book' ? <BookDetails /> :
                          view === 'blog' ? <BlogDetails /> :
                          <CourseDetails />;

  return (
    <div className="app-container">
      <h1>Blogger App</h1>
      <div className="buttons">
        <button onClick={() => setView('book')}>Book</button>
        <button onClick={() => setView('blog')}>Blog</button>
        <button onClick={() => setView('course')}>Course</button>
      </div>
      
      {/* Conditional rendering using element variable */}
      {elementVariable}

      {/* Conditional rendering using ternary operator */}
      {view === 'blog' ? <p>Showing Blog Details</p> : <p>Not showing Blog</p>}

      {/* Conditional rendering using && */}
      {view === 'course' && <p>Extra details for Course displayed with &&</p>}
    </div>
  );
}

export default App;
