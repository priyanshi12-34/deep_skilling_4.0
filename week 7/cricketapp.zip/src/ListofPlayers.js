import React from 'react';

const players = [
  { name: 'Player1', score: 80 },
  { name: 'Player2', score: 60 },
  { name: 'Player3', score: 90 },
  { name: 'Player4', score: 55 },
  { name: 'Player5', score: 76 },
  { name: 'Player6', score: 35 },
  { name: 'Player7', score: 82 },
  { name: 'Player8', score: 45 },
  { name: 'Player9', score: 93 },
  { name: 'Player10', score: 68 },
  { name: 'Player11', score: 74 }
];

const ListofPlayers = () => {
  const filteredPlayers = players.filter(player => player.score >= 70);

  return (
    <div>
      <h2>List of Players with score ≥ 70</h2>
      <ul>
        {filteredPlayers.map((player, index) => (
          <li key={index}>{player.name} - {player.score}</li>
        ))}
      </ul>
    </div>
  );
};

export default ListofPlayers;
