# Factory Method Pattern Example

This Java project demonstrates the Factory Method Design Pattern to create different types of documents (Word, PDF, Excel).

## 📂 Structure

- `Document.java` - Interface for documents
- `WordDocument.java`, `PdfDocument.java`, `ExcelDocument.java` - Concrete implementations
- `DocumentFactory.java` - Abstract factory class
- `WordFactory.java`, `PdfFactory.java`, `ExcelFactory.java` - Concrete factories
- `Main.java` - Demo usage

## ▶️ How to Run

1. Compile all Java files:
   ```bash
   javac *.java
   ```

2. Run the main class:
   ```bash
   java Main
   ```

## ✅ Output

```
Opening Word document...
Opening PDF document...
Opening Excel document...
```
