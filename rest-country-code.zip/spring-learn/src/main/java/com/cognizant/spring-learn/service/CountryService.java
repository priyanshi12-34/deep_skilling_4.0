
package com.cognizant.spring-learn.service;

import com.cognizant.spring-learn.model.Country;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class CountryService {

    private List<Country> countryList = new ArrayList<>();

    @PostConstruct
    public void loadCountries() {
        try {
            InputStream inputStream = getClass().getResourceAsStream("/country.xml");
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputStream);
            NodeList countries = doc.getElementsByTagName("country");

            for (int i = 0; i < countries.getLength(); i++) {
                Node node = countries.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    String code = element.getElementsByTagName("code").item(0).getTextContent();
                    String name = element.getElementsByTagName("name").item(0).getTextContent();
                    countryList.add(new Country(code, name));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Country getCountry(String code) {
        return countryList.stream()
                .filter(c -> c.getCode().equalsIgnoreCase(code))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Country not found for code: " + code));
    }
}
