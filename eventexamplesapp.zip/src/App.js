import React, { Component } from 'react';
import CurrencyConvertor from './CurrencyConvertor';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
  }

  increment = () => {
    this.setState({ count: this.state.count + 1 });
    this.sayHello();
  };

  sayHello = () => {
    alert("Hello! Counter was incremented.");
  };

  decrement = () => {
    this.setState({ count: this.state.count - 1 });
  };

  sayWelcome = (message) => {
    alert(message);
  };

  handleClick = (event) => {
    alert("I was clicked (Synthetic Event)");
  };

  render() {
    return (
      <div>
        <h1>React Event Handling Example</h1>
        <p>Counter: {this.state.count}</p>
        <button onClick={this.increment}>Increment</button>
        <button onClick={this.decrement}>Decrement</button>
        <br /><br />
        <button onClick={() => this.sayWelcome("Welcome to the React Event Lab!")}>Say Welcome</button>
        <br /><br />
        <button onClick={this.handleClick}>OnPress</button>
        <br /><br />
        <CurrencyConvertor />
      </div>
    );
  }
}

export default App;
