import React, { useState } from 'react';

function CurrencyConvertor() {
  const [rupees, setRupees] = useState('');
  const [euro, setEuro] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    const rate = 0.011; // 1 INR = 0.011 Euro approx
    setEuro((rupees * rate).toFixed(2));
  };

  return (
    <div>
      <h2>Currency Convertor</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Rupees:
          <input
            type="number"
            value={rupees}
            onChange={(e) => setRupees(e.target.value)}
          />
        </label>
        <button type="submit">Convert</button>
      </form>
      {euro !== null && (
        <p>{rupees} INR is equal to €{euro}</p>
      )}
    </div>
  );
}

export default CurrencyConvertor;
