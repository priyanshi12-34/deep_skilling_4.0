# React Hands-on Lab

## Setup Instructions

1. Make sure Node.js and npm are installed:
   https://nodejs.org/en/download/

2. Open terminal/command prompt in the project folder.

3. Run:
   npm install

4. Then run:
   npm start

5. Open your browser and go to:
   http://localhost:3000

You will see:
"welcome to the first session of React"
