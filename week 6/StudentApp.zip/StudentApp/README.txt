# StudentApp - React Hands-on Lab

## Setup Instructions

1. Install Node.js and npm: https://nodejs.org/en/download/
2. Open terminal in the project folder.
3. Run:
   npm install
4. Then start the app:
   npm start
5. Open your browser and visit:
   http://localhost:3000

## Description
This app includes three components:
- Home
- About
- Contact

Each component displays a welcome message as per lab requirements.
