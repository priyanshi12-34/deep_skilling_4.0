# Score Calculator App - React Hands-on Lab

## Setup Instructions

1. Install Node.js and npm: https://nodejs.org/en/download/
2. Open terminal in this folder.
3. Run:
   npm install
4. Then start the app:
   npm start
5. Visit in browser:
   http://localhost:3000

## Description

This project includes:
- Functional component `CalculateScore` that accepts Name, School, Total, and Goal
- Computes and displays average score
- Styled using custom CSS in `Stylesheets/mystyle.css`
