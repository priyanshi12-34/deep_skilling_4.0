import React from 'react';
import CalculateScore from './Components/CalculateScore';

function App() {
  return (
    <div>
      <CalculateScore Name="Priyanshi" School="ABC Public School" Total={480} Goal={6} />
    </div>
  );
}

export default App;
