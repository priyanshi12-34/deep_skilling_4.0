import React from 'react';
import CohortDetails from './CohortDetails';

function App() {
  const cohorts = [
    { name: 'React Basics', status: 'ongoing', start: '2025-06-01', end: '2025-07-15' },
    { name: 'Spring Boot', status: 'completed', start: '2025-04-10', end: '2025-05-25' }
  ];

  return (
    <div>
      <h1>Cohort Dashboard</h1>
      {cohorts.map((cohort, index) => (
        <CohortDetails key={index} cohort={cohort} />
      ))}
    </div>
  );
}

export default App;