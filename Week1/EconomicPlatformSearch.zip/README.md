
# E-commerce Platform Search Function

## Files
- `Product.java`: Defines the Product class.
- `SearchAlgorithms.java`: Implements linear and binary search.
- `Main.java`: Demonstrates searching with a sample product list.

## Features
- Demonstrates understanding of Big O notation.
- Implements both linear and binary search.
- Compares performance of search methods.

## Time Complexities

| Algorithm | Best Case | Average Case | Worst Case |
|-----------|-----------|--------------|-------------|
| Linear    | O(1)      | O(n)         | O(n)        |
| Binary    | O(1)      | O(log n)     | O(log n)    |
