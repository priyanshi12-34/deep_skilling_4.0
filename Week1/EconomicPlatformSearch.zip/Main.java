
import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Shoes", "Footwear"),
            new Product(103, "Smartphone", "Electronics"),
            new Product(104, "Watch", "Accessories")
        };

        // Sort products by productName for binary search
        Arrays.sort(products, Comparator.comparing(p -> p.productName));

        String searchName = "Shoes";

        Product foundLinear = SearchAlgorithms.linearSearch(products, searchName);
        System.out.println("Linear Search Result: " + (foundLinear != null ? foundLinear : "Not Found"));

        Product foundBinary = SearchAlgorithms.binarySearch(products, searchName);
        System.out.println("Binary Search Result: " + (foundBinary != null ? foundBinary : "Not Found"));
    }
}
